#include <ctype.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <windows.h>

#define R 0.16
/*#define RESET "\033[0m"
#define BOLDBLACK "\033[1m\033[30m"*/

struct stack
{
    int top;
    int items[20];
};

struct customer_details
{
    char username[15];
    int userid;
    float amount;
    int sbaccountno;
    char password[10];
    char tpassword[10];
}C1;
struct customer_details *C=&C1;
void display(struct customer_details *C)
{
        printf("\n\t\t%s your account details are:\n",C->username);
        printf("\n\t\t\tUserID:%d\n\t\t\tYour balance is:%.2f\n\t\t\tYour saving bank account number:%d\n",C->userid,C->amount,C->sbaccountno);

}

/*struct customer_details*/
void fndeposit(struct customer_details *P,float deposit)
{
    //struct customer_details &P;
    FILE *fp;
    fp=fopen("file3.txt","r+");
    printf("\n\t\tYou have successfully deposited %.2f\n",deposit);
    P->amount=P->amount+deposit;
    fprintf(fp,"%.2f",P->amount);
    printf("\n\t\t.......\n");
    display(P);
    return ;

}
/*struct customer_details*/
void fnwithdraw(struct customer_details *P,float withdraw)
{
    //printf("\n\t\t%d is withdrawn\n",withdraw);
    if(P->amount==withdraw)
    {
        P->amount=0;
        display(P);
        printf("Your account balance would be ZERO ");
    }
    else if(P->amount<withdraw)
    {
        printf("Insufficient balance to withdraw");
    }
    else
    {
        P->amount=P->amount-withdraw;
        display(P);
    }
    return;
}

void transfer(struct customer_details *P1,int userid1,float amount1)
{
    struct customer_details *P=&C1;
    int cd;
    FILE *fp;
    fp=fopen("file3.txt","a+");
    if(fp==NULL)
    {
        printf("\n\t\tError in opening file");
        exit(0);
    }
    else
    {
        while(fscanf(fp,"%s%d%d%s%f%s",P->username,&P->userid,&P->sbaccountno,P->password,&P->amount,P->tpassword)!=EOF)
        {
            if(P->userid==userid1)
            {
                P->amount=P->amount+amount1;
                cd=1;
                display(P);
                printf("\n\t\t%.2f is deducted from %s",amount1,P1->username);
                P1->amount=P1->amount-amount1;
                display(P1);
                break;
            }
        }
    }
    if(cd==0)   printf("\n\t\tRecord not found");
    fclose(fp);
    return ;
}
struct customer_details fnsearch(int id, char pwd[10])
{
    int abc=0;
    FILE *fp1;
    fp1=fopen("file3.txt","a+");
    if(fp1==NULL)
    {
        printf("\n\t\tError in opening file");
        exit(0);
    }
    else
    {
        while(fscanf(fp1,"%s%d%d%s%f%s",C1.username,&C1.userid,&C1.sbaccountno,C1.password,&C1.amount,C1.tpassword)!=EOF)
        {
           if(C1.userid==id)
            {
               if(strcmp(C1.password,pwd)==0)
                {
                    abc=1;
                    display(C);
                    return(C1);
                    break;
                }
            }

        }
        if(abc==0)
        {
            printf("\n\t\tPassword didnot match\n");
            exit(0);
        }
        else
            printf("\n\t\tSearch successful");
    }
    fclose(fp1);
    //printf("\nExiting out of fnsearch");

}
int idsearch(int userID)
{
    int c;
    FILE *fp1;
    fp1=fopen("file3.txt","a+");
    if(fp1==NULL)
    {
        printf("\n\t\tError in opening file");
        exit(0);
    }
    else
    {
        while(fscanf(fp1,"%s%d%d%s%f%s",C1.username,&C1.userid,&C1.sbaccountno,C1.password,&C1.amount,C1.tpassword)!=EOF)
        {
            //printf("\ne..ooooooo..");
            if(C1.userid==userID)
            {
                c=1;
            }
            else
                c=0;

        }

    }
    return c;
}

float loan(float lamount,int time)
{
    float si=0;
    if(time==0)
        return lamount;
    else
    {
        //printf("hiii");
        si=lamount*time*R;
        lamount=lamount+si;
        time=time-1;
        return loan(lamount,time);
    }
}

void stackpush(struct stack *S,int ele)
{
    S->items[++S->top]=ele;
}
int stackpop(struct stack *S)
{
    int ele;
    ele=S->items[S->top];
    S->top=S->top-1;
    return ele;
}

int main()
{
    FILE *fp;
    //struct stack *S;
    struct customer_details C1,*C;
    C=&C1;
    int choice,id,option,i=0,j=0,k=0,d,p,m=0;
    int userid,number,t;
    float deposit,withdraw;
    float amount=0,tamount,ramount=0.0,res=0.0;
    char ch,ch1,pwd[15],name[15];
    char password[15],cpassword[15],tpassword[15],ctpassword[15],password1[15],tpassword1[15];
    //c.amount=0;
    while(1)
    {
        printf("\n\t\t\t\t         | |      ");
        printf("\n\t\t\t\t||      *|*|*    || ");
        printf("\n\t\t\t\t||     * | |     || ");
        printf("\n\t\t\t\t||      *|*|*    || ");
        printf("\n\t\t\t\t||       | | *   ||  ");
        printf("\n\t\t\t\t||      *|*|*    ||  ");
        printf("\n\t\t\t\t||       | |     ||  ");

        printf("\n\t\t\t$$$ WELCOME TO SIDDAGANGA BANKING $$$\n");
        printf("\t\t     ____________________________________________\n");

        printf("\n\t\t1:LOGIN\n\t\t2:NEW REGISTRATION\n");
        printf("\n\n\t\tEnter the choice you prefer: ");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:printf("\n\t\tEnter the registered user ID: ");//login//
                   scanf("%d",&id);
                   p=idsearch(id);
                   fflush(stdin);
                   if(p==1)
                   {

                       printf("\n\t\tEnter your password: ");
                       while(i<=15)//hide password from input terminal
                        {
                           pwd[i]=getch();
                           ch=pwd[i];
                           if(ch==13)   break;
                           else
                            printf("*");
                           i++;
                           /*if(i>8)
                           {
                            printf("\a");
                            break;
                           }*/
                        }
                        pwd[i]='\0';
                       // if(strlen(pwd)<8)
                         //   printf("\n\t\tWeak password");

                        C1=fnsearch(id,pwd);
                        while(1)
                        {
                           printf("\n\t\t### Here your options are: ###");
                           printf("\n\t\t1.Deposit\n\t\t2:Withdraw\n\t\t3:Transfer the money\n\t\t4:TO check balance\n\t\t5:To display the schemes available for your balance\n\t\t6:To get loan\n\t\t7:Logout\n");
                           printf("\n\t\tEnter your choice: ");
                           scanf("%d",&option);
                           switch(option)
                           {
                               case 1:printf("\n\t\tEnter the amount to be deposited: ");
                                      scanf("%f",&deposit);
                                      fndeposit(&C1,deposit);
                                      printf("\n\t\t%.2f is deposited\n",deposit);
                                      //stackpush(&S,deposit);
                                      fflush(stdin);
                                      break;
                               case 2:printf("\n\t\tEnter the amount to be withdrawn: ");
                                      scanf("%f",&withdraw);
                                      fnwithdraw(&C1,withdraw);
                                      //printf("\n\t\t%d is withdrawn\n",withdraw);
                                      /*C.amount=C.amount-withdraw;
                                      */
                                      //stackpush(&S,withdraw);
                                      fflush(stdin);
                                      break;
                               case 3:fflush(stdin);
                                      printf("\n\t\tOnly one transaction can be done at a time");
                                      printf("\n\t\tEnter your transaction password: ");
                                      while(m<=15)
                                        {
                                            tpassword[m]=getch();
                                            ch=tpassword[m];
                                            if(ch==13)   break;
                                            if(ch==8)    printf("\b \b");
                                            else
                                                printf("*");
                                            m++;
                                        }
                                        tpassword[m]='\0';

                                     if(strcmp(tpassword,C->tpassword)==0)
                                      {
                                          printf("\n\t\tEnter the user id for which money has to be transferred: ");
                                          scanf("%d",&userid);
                                          fflush(stdin);
                                          printf("\n\t\tEnter the amount to be transferred: ");
                                          fflush(stdin);
                                          scanf("%f",&tamount);
                                          transfer(&C1,userid,tamount);

                                      }
                                      else
                                        printf("\n\t\tTransaction cannot be done, as password did not match\n");
                                      break;

                               case 4:printf("\n\t\tCurrent balance is %.2f\n",C1.amount);
                                      break;

                               case 5:if(C1.amount> 100000)
                                        {
                                            printf("\n\t\t%s it's time to invest in our shares\n",C1.username);
                                            printf("\n\t\tAvailable choices are ");
                                        }
                                       else if(C1.amount<500)
                                       {
                                           printf("\n\t\tyour balance is low");
                                       }
                                       else
                                        printf("\n\t\tAs per your balance no schemes are available");
                                      break;
                               case 6:printf("\n\t\tEnter amount: ");
                                      scanf("%f",&ramount);
                                      printf("\n\t\tEnter time: ");
                                      scanf("%d",&t);
                                      res=loan(ramount,t);
                                      printf("\n%.2f is result",res);
                                      break;
                               case 7:printf("\n\t\tLogged out successfully\n");
                                      exit(0);
                               default:printf("\n\t\tOops!!! Invalid choice\n");

                            }
                        }
                   }
                   else
                        printf("\n\t\tOops!!! You have not registered\n");
                   break;


            case 2:fp=fopen("file3.txt","a+");
                   printf("\n\t\tPlease enter your name: ");
                   scanf("%s", name);
                   printf("\n\t\tHELLO!!! %s \n",name);
                   printf("\n\t\tEnter your user id: ");
                   scanf("%d",&userid);
                   d=idsearch(userid);
                   fflush(stdin);
                   if(d==0)
                   {
                        printf("\n\t\tEnter your savings account number: ");
                        scanf("%d",&number);
                        fflush(stdin);
                        printf("\n\t\tEnter Password more than 8 characters: ");
                        scanf("%s", password);
                        if(strlen(password)<8)
                        {
                            printf("\a");
                            printf("\n\t\tRe-enter your password: ");
                            scanf("%s", password1);
                            strcpy(password,password1);
                        }
                        //strcpy(password,password1);
                        printf("\n\t\tEnter your confirmation password: ");
                        while(k<=15)//hide password from input terminal
                        {
                            cpassword[k]=getch();
                            ch=cpassword[k];
                            if(ch==13)   break;
                            if(ch==8)    printf("\b \b");
                            else
                                printf("*");
                            k++;

                        }
                        cpassword[k]='\0';

                        if(strcmp(password,cpassword)==0)
                        {
                            fflush(stdin);
                            printf("\n\n\t\tEnter the transactional password: ");
                            scanf("%s", tpassword);
                            if(strlen(tpassword)<8)
                            {
                                printf("\a");
                                printf("\n\t\tRe-enter your transactional password: ");
                                scanf("%s",tpassword1);
                                strcpy(tpassword,tpassword1);
                            }
                            //strcpy(tpassword,tpassword1);
                            printf("\n\t\tEnter the confirmational transaction password: ");
                            while(j<=15)//hide password from input terminal
                            {
                                ctpassword[j]=getch();
                                ch1=ctpassword[j];
                                if(ch1==13)   break;
                                if(ch1==8)    printf("\b \b");
                                else
                                    printf("*");
                                j++;
                            }
                            ctpassword[j]='\0';

                            if(strcmp(tpassword,ctpassword)==0)
                            {
                                fflush(stdin);
                                printf("\n\t\tYou have registered successfully!!!\n");
                                fprintf(fp,"\n%s\t%d\t%d\t%s\t%f\t%s\n",name,userid,number,password,amount,tpassword);
                                fclose(fp);
                            }
                            else
                               printf("\n\t\tThe transactional password you entered did not match\n");
                        }
                        else
                        {
                           printf("\n\t\tThe password did not match\n");

                        }
                   }

                   else
                        printf("\n\t\tUser has already been registered\n");
                   break;

            default:printf("\n\t\tYou have entered wrong choice\n");
        }
    }

    return 0;
}
